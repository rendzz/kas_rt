<!DOCTYPE html>
<html>
  <head>
    <base href="<?php echo base_url();?>"/>
    <meta charset="utf-8">
    <title>Halaman tidak ditemukan</title>
		<link rel="icon" type="image/png" href="images/error-404.png">
		<style media="screen">
		body{
			background-color:#f1f1f1;
		}
		</style>
  </head>
  <body>
<center>
		<br><br><br>

          <img src="assets/error-404.png" alt="" />

<br><br>
          <div class="error-text">
          	<span>halaman yang Anda minta</span>
          	<span class="large-text">tidak dapat ditemukan</span>
          </div><br>

          	<a class="back-home" href="<?php echo base_url();?>">Halaman Utama</a>
</center>
  </body>
</html>
