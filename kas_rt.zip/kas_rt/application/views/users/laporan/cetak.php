<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $judul_web; ?></title>
    <base href="<?php echo base_url();?>"/>
  	<link rel="icon" type="image/png" href="assets/favicon.png"/>
    <style>
    table {
        border-collapse: collapse;
    }

    th, td {
      padding: 2px;
    }

    th {
        color: #222;
    }
    </style>
    <!-- <style type="text/css" media="print">
      @page { size: landscape; }
    </style> -->
  </head>
  <body onload="window.print()">

    <table border="0" width="100%">
      <tr style="border:1px solid #222;border-bottom:1px solid #fff;">
        <th colspan="4"><?php echo strtoupper($judul_web); ?></th>
      </tr>
      <tr style="border:1px solid #222;border-top:1px solid #fff;font-size:10px;">
        <td colspan="4" align="center"><?php echo strtoupper($tgl); ?> <br><br> </td>
      </tr>
      <tr style="background:#71DCFF;">
        <th width="45%">Keterangan</th>
        <th width="20%">Tanggal</th>
        <th width="15%">Jenis</th>
        <th width="20%">Jumlah</th>
      </tr>
      <?php
      $no=1;
       foreach ($sql->result() as $baris):
        ?>
        <tr>
            <td><?php echo $baris->keterangan; ?></td>
            <td align="center"><?php echo $this->Mcrud->tgl_id(date('d-m-Y', strtotime($baris->tanggal))); ?></td>
            <td style="color:blue;" align="center"><?php echo $baris->jenis; ?></td>
            <td style="color:blue;">Rp. <?php echo number_format($baris->jumlah,0,".",","); ?>,-</td>
        </tr>
      <?php
      endforeach; ?>
      <tr style="background:#71DCFF;">
        <th align="left" colspan="3">TOTAL KAS MASUK</th>
        <th align="left">Rp. <?php echo number_format($total_masuk,0,".",","); ?>,-</th>
      </tr>
      <tr style="background:#71DCFF;">
        <th align="left" colspan="3">TOTAL KAS KELUAR</th>
        <th align="left">Rp. <?php echo number_format($total_keluar,0,".",","); ?>,-</th>
      </tr>
      <tr style="background:#71DCFF;">
        <th align="left" colspan="1">TOTAL SALDO KAS</th>
        <td align="right" colspan="2">Total Kas Masuk - Total Kas Keluar &nbsp; </td>
        <th align="left">Rp. <?php echo number_format($total_masuk - $total_keluar,0,".",","); ?>,-</th>
      </tr>
    </table>
    <br>
    <br>
    <?php $this->load->view('users/laporan/ttd'); ?>

  </body>
</html>
