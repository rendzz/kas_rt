<div style="float:right;text-align:center;">
  SMPN 1 Metro, <?php echo $this->Mcrud->tgl_id(date('d-m-Y'),'full'); ?>
  <br><br><br><br>
  Koordinator, <br>
  Tegar Santosa
</div>
