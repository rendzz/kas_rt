<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?php echo $judul_web; ?></title>
    <base href="<?php echo base_url();?>"/>
  	<link rel="icon" type="image/png" href="assets/favicon.png"/>
    <style>
    table {
        border-collapse: collapse;
    }

    th, td {
      padding: 2px;
    }

    th {
        color: #222;
    }
    </style>
    <!-- <style type="text/css" media="print">
      @page { size: landscape; }
    </style> -->
  </head>
  <body onload="window.print()">
    <table border="0" width="100%">
      <tr style="border:1px solid #222;border-bottom:1px solid #fff;">
        <th colspan="4"><?php echo strtoupper($judul_web); ?></th>
      </tr>
      <tr style="border:1px solid #222;border-top:1px solid #fff;font-size:10px;">
        <td colspan="4" align="center"><?php echo strtoupper($tgl); ?> <br><br> </td>
      </tr>
    </table>
    <table border="1" width="100%">
      <tr style="background:#f1f1f1;">
        <th width="1%">No.</th>
        <th width="20%">Tanggal</th>
        <th width="59%">Keterangan</th>
        <th width="20%">Jumlah</th>
      </tr>
      <?php
      $no=1;
       foreach ($sql->result() as $baris):
        ?>
        <tr>
            <th><?php echo $no++; ?></th>
            <td align="center"><?php echo $this->Mcrud->tgl_id(date('d-m-Y', strtotime($baris->tanggal))); ?></td>
            <td><?php echo $baris->keterangan; ?></td>
            <td>Rp. <?php echo number_format($baris->jumlah,0,".",","); ?>,-</td>
        </tr>
      <?php
      endforeach; ?>
      <tr>
        <th colspan="3">TOTAL KESELURUHAN</th>
        <th align="left">
          Rp.
          <?php if ($jenis=="Masuk"){ ?>
            <?php echo number_format($total_masuk,0,".",","); ?>
          <?php }elseif ($jenis=="Keluar"){ ?>
            <?php echo number_format($total_keluar,0,".",","); ?>
          <?php } ?>
          ,-
        </th>
      </tr>
    </table>
    <br>
    <br>
    <?php $this->load->view('users/laporan/ttd'); ?>

  </body>
</html>
