<!-- Main content -->
<div class="content-wrapper">
  <!-- Content area -->
  <div class="content">

    <!-- Dashboard content -->
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
        <div class="panel panel-inverse">
            <div class="panel-heading">
                <div class="panel-heading-btn">
                    <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                    <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                    <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                    <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                </div>
                <h4 class="panel-title"><?php echo $judul_web; ?></h4>
            </div>
            <div class="panel-body">
                <?php
                echo $this->session->flashdata('msg');
                ?>
                <form class="form-horizontal" action="" data-parsley-validate="true" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                    <label class="control-label col-lg-3">Keterangan</label>
                    <div class="col-lg-9">
                      <input type="text" name="keterangan" class="form-control" value="" placeholder="Keterangan" required autofocus>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-lg-3">Tanggal</label>
                    <div class="col-lg-9">
                      <input type="text" name="tanggal" class="form-control" id="tgl_1" value="<?php echo date('d-m-Y'); ?>" placeholder="Tanggal" maxlength="10" required>
                    </div>
                  </div>
                  <?php if ($jenis=='rekap'){ ?>
                  <div class="form-group">
                    <label class="control-label col-lg-3">Jenis</label>
                    <div class="col-lg-9">
                      <select class="form-control default-select2" name="jenis" required>
                        <option value="">- PILIH -</option>
                        <option value="Masuk">Masuk</option>
                        <option value="Keluar">Keluar</option>
                      </select>
                    </div>
                  </div>
                  <?php } ?>
                  <div class="form-group">
                    <label class="control-label col-lg-3">Jumlah</label>
                    <div class="col-lg-9">
                      <input type="text" name="jumlah" class="form-control" id="harga" value="" placeholder="Jumlah" required>
                    </div>
                  </div>
                  <hr>
                  <a href="<?php echo strtolower($this->uri->segment(1)); ?>/<?php echo strtolower($this->uri->segment(2)); ?>/<?php echo strtolower($this->uri->segment(3)); ?>.html" class="btn btn-default"><< Kembali</a>
                  <button type="submit" name="btnsimpan" class="btn btn-primary" style="float:right;">Simpan</button>
                </form>
            </div>

        </div>
      </div>
    </div>
    <!-- /dashboard content -->

    <script src="assets/js/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="assets/panel/plugin/datetimepicker/jquery.datetimepicker.css"/>
    <script src="assets/panel/plugin/datetimepicker/jquery.datetimepicker.js"></script>
    <script>
    $('#tgl_1').datetimepicker({
      lang:'en',
      timepicker:false,
      format:'d-m-Y'
    });
    </script>

    <script type="text/javascript">
    var dengan_rupiah = document.getElementById('harga');
    dengan_rupiah.addEventListener('keyup', function(e)
    {
      dengan_rupiah.value = formatRupiah(this.value, 'Rp. ');
    });
    </script>
