<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kegiatan extends CI_Controller {

	public function index()
	{
		redirect('kegiatan/input');
	}

	public function input($aksi='', $id='')
	{
		$id = hashids_decrypt($id);
		$ceks 	 = $this->session->userdata('username');
		$id_user = $this->session->userdata('id_user');
		$level 	 = $this->session->userdata('level');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);

			// if ($data['user']->row()->level != 'admin') {
			// 		redirect('404_content');
			// }

			$this->db->order_by('id_kegiatan', 'DESC');
			$data['query'] = $this->db->get("tbl_kegiatan");

				if ($aksi == 't') {
					$p = "tambah";
					$data['Desa'] 	  = "+ Kegiatan";
				}elseif ($aksi == 'e') {
					$p = "edit";
					$data['Desa'] 	  = "Edit Kegiatan";
					$data['query'] = $this->db->get_where("tbl_kegiatan", array('id_kegiatan' => "$id"))->row();
					if ($data['query']->id_kegiatan=='') {redirect('404');}
				}
				elseif ($aksi == 'h') {
					$cek_data = $this->db->get_where("tbl_kegiatan", array('id_kegiatan' => "$id"));
					if ($cek_data->num_rows() != 0) {
							$this->db->delete('tbl_kegiatan', array('id_kegiatan' => $id));
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> Berhasil dihapus.
								</div>
								<br>'
							);
							redirect("kegiatan/input");
					}else {
						redirect('404_content');
					}
				}else{
					$p = "index";
					$data['judul_web'] 	  = "Pengelolaan Kas";
				}

					$this->load->view('users/header', $data);
					$this->load->view("users/kegiatan/$p", $data);
					$this->load->view('users/footer');

					date_default_timezone_set('Asia/Jakarta');
					$tgl = date('Y-m-d H:i:s');

					if (isset($_POST['btnsimpan'])) {
						$nama_kegiatan = htmlentities(strip_tags($this->input->post('nama_kegiatan')));
						$tempat 	 		 = htmlentities(strip_tags($this->input->post('tempat')));
						$waktu 	 		 	 = htmlentities(strip_tags($this->input->post('waktu')));

										$data = array(
											'nama_kegiatan' => $nama_kegiatan,
											'tempat'  		  => $tempat,
											'waktu'  	 			=> $waktu,
											'tgl_kegiatan'  => $tgl
										);
										$this->db->insert('tbl_kegiatan',$data);

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil disimpan.
											</div>
		 								 <br>'
										);

						 redirect("kegiatan/input/t");
					}


					if (isset($_POST['btnupdate'])) {
						$nama_kegiatan = htmlentities(strip_tags($this->input->post('nama_kegiatan')));
						$tempat 	 		 = htmlentities(strip_tags($this->input->post('tempat')));
						$waktu 	 		 	 = htmlentities(strip_tags($this->input->post('waktu')));

										$data = array(
											'nama_kegiatan' => $nama_kegiatan,
											'tempat'  		  => $tempat,
											'waktu'  	 			=> $waktu
										);
										$this->db->update('tbl_kegiatan',$data, array('id_kegiatan' => $id));

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil disimpan.
											</div>
		 								 <br>'
										);

						 redirect("kegiatan/input/e/".hashids_encrypt($id));
					}
		}
	}

}
