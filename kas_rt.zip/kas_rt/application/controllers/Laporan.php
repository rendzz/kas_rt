<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	public function index()
	{
		$ceks 	 = $this->session->userdata('username');
		$id_user = $this->session->userdata('id_user');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			    = $this->db->get_where('tbl_user', "username='$ceks'");
			$data['judul_web']			= "Laporan keuangan Desa Sentono";

					$this->load->view('users/header', $data);
					$this->load->view('users/laporan/lap', $data);
					$this->load->view('users/footer');

					if (isset($_POST['cetak_lap'])) {
						$jenis  = htmlentities(strip_tags($this->input->post('jenis')));
						$tgl1 	= date('d-m-Y', strtotime(htmlentities(strip_tags($this->input->post('tgl1')))));
						$tgl2 	= date('d-m-Y', strtotime(htmlentities(strip_tags($this->input->post('tgl2')))));

						redirect("laporan/cetak_lap/$tgl1/$tgl2/$jenis");
					}
		}
	}

	public function cetak_lap($tgl_1='',$tgl_2='',$jenis='')
	{
		$ceks 	 = $this->session->userdata('username');
		$id_user = $this->session->userdata('id_user');
	  $level 	 = $this->session->userdata('level');
			if(!isset($ceks)) {
				redirect('web/login');
			}else{

				$data['user']  		 = $this->db->get_where('tbl_user', "username='$ceks'");

					if ($tgl_1 != '' AND $tgl_2 != '' AND $jenis != '') {
							$tgl1 	= date('Y-m-d', strtotime($tgl_1));
							$tgl2 	= date('Y-m-d', strtotime('+1 days', strtotime($tgl_2)));

							if ($tgl_1==$tgl_2) {
								$data['tgl'] = "TANGGAL ".date('d/ m/ Y',strtotime($tgl_1));
							}else {
								$data['tgl'] = "DARI TANGGAL ".date('d/ m/ Y',strtotime($tgl_1))." SAMPAI DENGAN TANGGAL ".date('d/ m/ Y',strtotime($tgl_1));
							}

							if ($jenis=='Rekapitulasi') {
								$qjenis  = "";
								$v_cetak = "cetak";
								$judul   = "Laporan $jenis keuangan Desa Sento";
							}else {
								$qjenis  = "AND jenis='$jenis'";
								$v_cetak = "cetak2";
								$judul   = "Laporan Kas $jenis Ketua RT Desa Sentono";
							}
							$sql = $this->db->query("SELECT * FROM tbl_data WHERE (tbl_data.tanggal BETWEEN '$tgl1' AND '$tgl2') $qjenis ORDER BY tbl_data.tanggal ASC");
							$sql_masuk  = $this->db->query("SELECT SUM(jumlah) AS total, tbl_data.* FROM tbl_data WHERE (tbl_data.tanggal BETWEEN '$tgl1' AND '$tgl2') AND jenis='Masuk' ORDER BY tbl_data.tanggal ASC")->row()->total;
							$sql_keluar = $this->db->query("SELECT SUM(jumlah) AS total, tbl_data.* FROM tbl_data WHERE (tbl_data.tanggal BETWEEN '$tgl1' AND '$tgl2') AND jenis='Keluar' ORDER BY tbl_data.tanggal ASC")->row()->total;
							$data['sql'] 	 = $sql;
							$data['jenis'] = $jenis;
							$data['total_masuk']  = $sql_masuk;
							$data['total_keluar'] = $sql_keluar;
							$data['judul_web'] = $judul;

							$this->load->view("users/laporan/$v_cetak", $data);

					}else{
							redirect('404_content');
					}

			}
	}


	public function kegiatan()
	{
		$ceks 	 = $this->session->userdata('username');
		$id_user = $this->session->userdata('id_user');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			    = $this->db->get_where('tbl_user', "username='$ceks'");
			$data['judul_web']			= "Laporan Kegiatan Desa Sentono";

					$this->load->view('users/header', $data);
					$this->load->view('users/laporan/lap', $data);
					$this->load->view('users/footer');

					if (isset($_POST['cetak_lap'])) {
						$tgl1 	= date('d-m-Y', strtotime(htmlentities(strip_tags($this->input->post('tgl1')))));
						$tgl2 	= date('d-m-Y', strtotime(htmlentities(strip_tags($this->input->post('tgl2')))));

						redirect("laporan/cetak_kegiatan/$tgl1/$tgl2");
					}
		}
	}

	public function cetak_kegiatan($tgl_1='',$tgl_2='')
	{
		$ceks 	 = $this->session->userdata('username');
		$id_user = $this->session->userdata('id_user');
	  $level 	 = $this->session->userdata('level');
			if(!isset($ceks)) {
				redirect('web/login');
			}else{

				$data['user']  		 = $this->db->get_where('tbl_user', "username='$ceks'");

					if ($tgl_1 != '' AND $tgl_2 != '') {
							$tgl1 	= date('Y-m-d', strtotime($tgl_1));
							$tgl2 	= date('Y-m-d', strtotime('+1 days', strtotime($tgl_2)));

							if ($tgl_1==$tgl_2) {
								$data['tgl'] = "TANGGAL ".date('d/ m/ Y',strtotime($tgl_1));
							}else {
								$data['tgl'] = "DARI TANGGAL ".date('d/ m/ Y',strtotime($tgl_1))." SAMPAI DENGAN TANGGAL ".date('d/ m/ Y',strtotime($tgl_1));
							}

							$sql = $this->db->query("SELECT * FROM tbl_kegiatan WHERE (tbl_kegiatan.tgl_kegiatan BETWEEN '$tgl1' AND '$tgl2') ORDER BY tbl_kegiatan.id_kegiatan ASC");
							$data['sql'] 	 = $sql;
							$data['judul_web'] = "Laporan Kegiatan Desa Sentono";

							$this->load->view("users/laporan/cetak_kegiatan", $data);

					}else{
							redirect('404_content');
					}

			}
	}


}
