<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {

	public function index()
	{
		redirect('404');
	}

	public function input($kas='',$aksi='', $id='')
	{
		$id = hashids_decrypt($id);
		$ceks 	 = $this->session->userdata('username');
		$id_user = $this->session->userdata('id_user');
		$level 	 = $this->session->userdata('level');
		if(!isset($ceks)) {
			redirect('web/login');
		}else{
			$data['user']  			  = $this->Mcrud->get_users_by_un($ceks);

			// if ($data['user']->row()->level != 'admin') {
			// 		redirect('404_content');
			// }
			if ($kas=='masuk') {
				$txt  = "Manajemen Kas Masuk Dan sumber anggaran";
				$txt2 = "Data Kas";
			}elseif ($kas=='keluar') {
				$txt  = "Manajemen Kas Keluar";
				$txt2 = "Data Kas Keluar";
			}else {
				$txt  = "Manajemen Kas Rekapitulasi";
				$txt2 = "Kas Rekapitulasi";
			}
			if ($kas!='rekap') {
				$this->db->where('jenis',"$kas");
			}
			$data['txt2'] = $txt2;

			$this->db->order_by('id_data', 'DESC');
			$data['query'] = $this->db->get("tbl_data");

				if ($aksi == 't') {
					$p = "tambah";
					$data['judul_web'] 	  = "Tambah $txt2";
				}elseif ($aksi == 'e') {
					$p = "edit";
					$data['judul_web'] 	  = "Edit $txt2";
					if ($kas!='rekap') {
						$this->db->where('jenis',"$kas");
					}
					$data['query'] = $this->db->get_where("tbl_data", array('id_data' => "$id"))->row();
					if ($data['query']->id_data=='') {redirect('404');}
				}
				elseif ($aksi == 'h') {
					if ($kas!='rekap') {
						$this->db->where('jenis',"$kas");
					}
					$cek_data = $this->db->get_where("tbl_data", array('id_data' => "$id"));
					if ($cek_data->num_rows() != 0) {
							$this->db->delete('tbl_data', array('id_data' => $id));
							$this->session->set_flashdata('msg',
								'
								<div class="alert alert-success alert-dismissible" role="alert">
									 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
									 </button>
									 <strong>Sukses!</strong> Berhasil dihapus.
								</div>
								<br>'
							);
							redirect("data/input/$kas");
					}else {
						redirect('404_content');
					}
				}else{
					$p = "index";
					$data['judul_web'] 	  = "Pengelolaan Kas";
				}
				$data['jenis'] = $kas;
				$data['txt'] 	 = $txt;

					$this->load->view('users/header', $data);
					$this->load->view("users/data/$p", $data);
					$this->load->view('users/footer');

					date_default_timezone_set('Asia/Jakarta');
					$tgl = date('Y-m-d H:i:s');

					if (isset($_POST['btnsimpan'])) {
						$keterangan = htmlentities(strip_tags($this->input->post('keterangan')));
						$tanggal		= date('Y-m-d',strtotime(htmlentities(strip_tags($this->input->post('tanggal')))));
						if ($kas=='rekap') {
							$jenis = htmlentities(strip_tags($this->input->post('jenis')));
						}else {
							$jenis = ucwords($kas);
						}
						$jumlah			= preg_replace('/[Rp. ]/','',htmlentities(strip_tags($this->input->post('jumlah'))));

										$data = array(
											'keterangan' => $keterangan,
											'tanggal' 	 => $tanggal,
											'jenis'  		 => $jenis,
											'jumlah'  	 => $jumlah,
											'tgl_data'   => $tgl
										);
										$this->db->insert('tbl_data',$data);

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil disimpan.
											</div>
		 								 <br>'
										);

						 redirect("data/input/$kas/t");
					}


					if (isset($_POST['btnupdate'])) {
						$keterangan = htmlentities(strip_tags($this->input->post('keterangan')));
						$tanggal		= date('Y-m-d',strtotime(htmlentities(strip_tags($this->input->post('tanggal')))));
						if ($kas=='rekap') {
							$jenis = htmlentities(strip_tags($this->input->post('jenis')));
						}else {
							$jenis = ucwords($kas);
						}
						$jumlah			= preg_replace('/[Rp. ]/','',htmlentities(strip_tags($this->input->post('jumlah'))));

										$data = array(
											'keterangan' => $keterangan,
											'tanggal' 	 => $tanggal,
											'jenis'  		 => $jenis,
											'jumlah'  	 => $jumlah
										);
										$this->db->update('tbl_data',$data, array('id_data' => $id));

										$this->session->set_flashdata('msg',
											'
											<div class="alert alert-success alert-dismissible" role="alert">
												 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													 <span aria-hidden="true">&times;&nbsp; &nbsp;</span>
												 </button>
												 <strong>Sukses!</strong> Berhasil disimpan.
											</div>
		 								 <br>'
										);

						 redirect("data/input/$kas/e/".hashids_encrypt($id));
					}
		}
	}

}
